package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.DAO.ViewreportDao;
import com.cognizant.model.Claimdetails;
/* Empid:900843 Name:Uppuluri Venkata Dharma Teja */

@Service
public class ViewreportService {
	@Autowired
	ViewreportDao vdao;

	public Claimdetails getClaimdetails(long policyid, long claimid) {
		return vdao.getClaimdetails(policyid, claimid);
	}

}
