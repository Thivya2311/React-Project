package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.DAO.FaqDao;
import com.cognizant.model.Faq;

import java.util.List;

/*Empid:901096Name:Amit Gawande*/
@Service
public class Faqservice {
	@Autowired
	FaqDao fdao;

	public List<Faq> getAllFaq() {
		System.out.println(fdao.findAll());
		return fdao.findAll();
	}
}
