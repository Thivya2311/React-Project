package com.cognizant.service;

public interface UserAuthenticationService {
	
	/* Empid:901013 Name:Thivya Bharathy T */

	boolean validateUserLogin(String email, String password);

	/* Empid:901049 Name:Abhishek */

	boolean changePassword(String email, String password);

}
