package com.cognizant.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.DAO.ClaimdetailsDao;
import com.cognizant.model.Claimdetails;
import com.cognizant.model.policy;

@Service
public class ClaimdetailsService {

	@Autowired
	ClaimdetailsDao claimDao;

	/* Empid:900886 Name:Harika Bonala */
	
	public void insert(Claimdetails claimdetails) {
		claimDao.save(claimdetails);
	}

	/* Empid:901049 Name:Abhishek E */
	
	public void deleteClaim(long policyid) {
		claimDao.deleteById(policyid);
	}

	public Claimdetails getClaim(long claimid) {
		return claimDao.findById(claimid).orElse(null);
	}

	/* Empid:901013 Name:Thivya Bharathy T */
	
	public void updateClaim(long claimid, Claimdetails claimdetails) {
		claimdetails.setClaimid(claimid);
		claimDao.save(claimdetails);
	}

	public List<Claimdetails> getAllClaim() {

		List<Claimdetails> claimList = new ArrayList<>();
		claimDao.findAll().forEach(claimList::add);
		return claimList;

	}


}
