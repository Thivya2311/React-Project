package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cognizant.DAO.UserDao;
import com.cognizant.model.UserDetails;

@Service
public class UserAuthenticationServiceImpl implements UserAuthenticationService {

	@Autowired
	private UserDao userDao;

	/* Empid:901013 Name:Thivya Bharathy T */
	
	public boolean validateUserLogin(String email, String password) {
		UserDetails existingUser = userDao.find(email);
		System.out.println("hanuman");
		System.out.println(existingUser);
		if (existingUser != null) {
			if (existingUser.getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}

	/* Empid:901049 Name:Abhishek */
	
	public boolean changePassword(String email, String password) {
		UserDetails existingUser = userDao.find(email);
		System.out.println(existingUser);
		if (existingUser != null) {
			int response = userDao.setPassword(password, email);
			return true;
		}
		return false;

	}

}
