package com.cognizant.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.DAO.policyDao;
import com.cognizant.model.policy;

/*Empid:901096 Name:Amit Gawande*/

@Service
public class policyService {

	@Autowired
	private policyDao pdao;

	public policy getpolicydetails(long policyid) {
		return pdao.getpolicydetails(policyid);
	}

	/* Empid:901049 Name:Abhishek E */

	public void addPolicy(policy policy) {
		pdao.save(policy);
	}

	public void deletePolicy(long policyid) {
		pdao.deleteById(policyid);
	}

	public void updatePolicy(long policyid, policy policy) {
		policy.setPolicyid(policyid);
		pdao.save(policy);
	}
	/* Empid:901013 Name:Thivya Bharathy T */

	public List<policy> getAllPolicies() {
		List<policy> policyList = new ArrayList<>();
		pdao.findAll().forEach(policyList::add);
		return policyList;
	}

	public policy getPolicy(long policyid) {
		return pdao.findById(policyid).orElse(null);
	}

}
