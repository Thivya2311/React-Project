package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.DAO.ContactDao;
import com.cognizant.model.Claimdetails;
import com.cognizant.model.Contact;
import com.cognizant.model.policy;


/* 900886 Harika Bonala*/


@Service
public class ContactService {
    @Autowired
	ContactDao cdao;
    public void addMessage(Contact contact)
    {
    	cdao.save(contact);
    }
  
	public Contact getresponse(String email)
    {
    	return cdao.getresponse(email);
    }

	/* Empid:900843 Name:Uppuluri Venkata Dharma Teja */
	public void deleteUserResponse(String email) {
		// TODO Auto-generated method stub
		cdao.deleteById(email);
	
	}
	/* Empid:901049 Name:Thivya Bharathy T*/
	public void updateUserResponse(Contact contact, String email) {
		// TODO Auto-generated method stub
		contact.setEmail(email);
	    cdao.save(contact);
		
	}
	/* Empid:901049 Name:Abhishek E */
	public List<Contact> getAllResponses() {
		List<Contact> responseList = new ArrayList<>();
	    cdao.findAll().forEach(responseList::add);
	    return responseList;
	}

	
	public Contact getUserResponse(String email) {
		return cdao.findById(email).orElse(null);
	}
}
