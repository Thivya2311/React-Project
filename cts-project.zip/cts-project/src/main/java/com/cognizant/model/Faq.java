package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/*Empid:901096 Name:Amit Gawande*/
@Entity
public class Faq {
	@Id
	private int qid;
	private String question;
	private String answer;

	public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Faq [qid=" + qid + ", question=" + question + ", answer=" + answer + "]";
	}

}
