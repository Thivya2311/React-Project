package com.cognizant.model;

/*Empid:901096 Name:Amit Gawande*/
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class policy {
	@Id
	private long policyid;
	private String name;
	private String email;
	private String policyName;

	public long getPolicyid() {
		return policyid;
	}

	public void setPolicyid(long policyid) {
		this.policyid = policyid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	@Override
	public String toString() {
		return "policy [policyid=" + policyid + ", name=" + name + ", email=" + email + ", policyName=" + policyName
				+ "]";
	}

}
