package com.cognizant.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*Empid:900886 Name:Harika Bonala*/
@Entity
@Table(name = "claimdetails")
public class Claimdetails {
	@Id
	private long policyid;
	private Date dateOfLoss;
	private String desOfLoss;
	private String email;
	private double estLoss;
	private String gender;
	private String locOfLoss;
	private String name;
	private String phoneNumber;
	private long claimid;
	private String policyName;

	public long getPolicyid() {
		return policyid;
	}

	public void setPolicyid(long policyid) {
		this.policyid = policyid;
	}

	public Date getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(Date dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public String getDesOfLoss() {
		return desOfLoss;
	}

	public void setDesOfLoss(String desOfLoss) {
		this.desOfLoss = desOfLoss;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getEstLoss() {
		return estLoss;
	}

	public void setEstLoss(double estLoss) {
		this.estLoss = estLoss;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLocOfLoss() {
		return locOfLoss;
	}

	public void setLocOfLoss(String locOfLoss) {
		this.locOfLoss = locOfLoss;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public long getClaimid() {
		return claimid;
	}

	public void setClaimid(long claimid) {
		this.claimid = claimid;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	@Override
	public String toString() {
		return "Claimdetails [policyid=" + policyid + ", dateOfLoss=" + dateOfLoss + ", desOfLoss=" + desOfLoss
				+ ", email=" + email + ", estLoss=" + estLoss + ", gender=" + gender + ", locOfLoss=" + locOfLoss
				+ ", name=" + name + ", phoneNumber=" + phoneNumber + ", claimid=" + claimid + ", policyName="
				+ policyName + "]";
	}

}
