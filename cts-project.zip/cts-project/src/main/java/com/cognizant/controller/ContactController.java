package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Contact;
import com.cognizant.model.policy;
import com.cognizant.service.ContactService;

/* 900886 Harika Bonala */
@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class ContactController {
	@Autowired
	private ContactService cService;

	@PostMapping("/contact")
	public void addMessage(@RequestBody Contact contact) {

		cService.addMessage(contact);
	}

	@GetMapping("/viewresponse/{email}")
	public Contact getresponse(@PathVariable(value = "email") String email) {

		return cService.getresponse(email);
	}

	/* Empid:901013 Name:Thivya Bharathy T */
	@GetMapping("/responses")
	public List<Contact> getAllResponses() {
		return cService.getAllResponses();
	}

	@GetMapping("/response/{id}")
	public Contact getResponse(@PathVariable(value = "id") String email) {
		return cService.getUserResponse(email);
	}

	/* Empid:901049 Name:Abhishek E */
	@PutMapping("/responses/{id}")
	public void updateUserResponse(@RequestBody Contact contact, @PathVariable(value = "id") String email) {
		cService.updateUserResponse(contact, email);
	}

	@DeleteMapping("/response/{id}")
	public void deleteUserResponse(@PathVariable(value = "id") String email) {
		cService.deleteUserResponse(email);
	}
}
