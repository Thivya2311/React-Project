package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Faq;
import com.cognizant.service.Faqservice;

/*Empid:901096 Name:Amit Gawande*/
@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class FaqController {
	@Autowired
	Faqservice fservice;

	@GetMapping("/faq")
	public List<Faq> getAllFaq() {
		System.out.println("faqs");
		return fservice.getAllFaq();
	}
}
