package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.policy;
import com.cognizant.service.policyService;

/*Empid:901096 Name:Amit Gawande*/

@RestController
//@RequestMapping("/claimpolicy")
@CrossOrigin(origins = "http://localhost:3000")

public class policyController {

	@Autowired
	private policyService pservice;

	@RequestMapping(value = "/claimpolicy/{policyid}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public policy getpolicydetails(@PathVariable(value = "policyid") long policyid) {
		System.out.println(pservice.getpolicydetails(policyid));
		return pservice.getpolicydetails(policyid);
	}

	/* Empid:901049 Name:Abhishek E */

	@PostMapping("/policy")
	public void addPerson(@RequestBody policy policy) {
		System.out.println("add policy");
		pservice.addPolicy(policy);
	}

	@PutMapping("/policies/{id}")
	public void updateStudent(@RequestBody policy policy, @PathVariable(value = "id") long policyid) {
		pservice.updatePolicy(policyid, policy);
	}

	@DeleteMapping("/policies/{id}")
	public void deletePerson(@PathVariable(value = "id") long policyid) {
		pservice.deletePolicy(policyid);
	}

	/* Empid:901013 Name:Thivya Bharathy T */

	@GetMapping("/policies")
	public List<policy> getAllPersons() {
		return pservice.getAllPolicies();
	}

	@GetMapping("/policies/{id}")
	public policy getPerson(@PathVariable(value = "id") long policyid) {
		return pservice.getPolicy(policyid);
	}

}
