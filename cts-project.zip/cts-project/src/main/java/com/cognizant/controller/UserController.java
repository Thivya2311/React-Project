package com.cognizant.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.UserDetails;
import com.cognizant.model.UserLogin;
import com.cognizant.service.UserAuthenticationService;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

	@Autowired
	private UserAuthenticationService userService;

	/* Empid:901013 Name:Thivya Bharathy T */
	
	@PostMapping("/login")
	@ResponseStatus(HttpStatus.OK)
	public boolean validate(@RequestBody UserLogin login) {
		System.out.println(login);
		boolean status = userService.validateUserLogin(login.getEmail(), login.getPassword());
		if (status)
			return status;
		else
			return (Boolean) null;
	}

	@GetMapping("/logout")
	public boolean logout(HttpSession session) {
		session.invalidate();

		return false;
	}

	/* Empid:901049 Name:Abhishek E */

	@PostMapping("/changePassword")
	@ResponseStatus(HttpStatus.OK)
	public boolean changePassword(@RequestBody UserLogin login) {
		boolean status = userService.changePassword(login.getEmail(), login.getPassword());

		return status;

	}

}
