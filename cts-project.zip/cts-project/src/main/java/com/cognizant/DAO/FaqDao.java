package com.cognizant.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.model.Faq;

/*Empid:901096 Name:Amit Gawande*/
public interface FaqDao extends JpaRepository<Faq, Integer> {

}
