package com.cognizant.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Claimdetails;

/*Empid:900843 Name:Uppuluri Venkata Dharma Teja*/

@Repository
public interface ViewreportDao extends JpaRepository<Claimdetails, Long> {

	@Query(value = "SELECT * FROM claimdetails where policyid=? and claimid=?", nativeQuery = true)
	public Claimdetails getClaimdetails(long policyid, long claimid);
}
