package com.cognizant.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant.model.Contact;

/*Empid:900886 Name:Harika Bonala*/

public interface ContactDao extends JpaRepository<Contact, String> {
	@Query(value = "select * from contact where email=?", nativeQuery = true)
	public Contact getresponse(String email);
}
