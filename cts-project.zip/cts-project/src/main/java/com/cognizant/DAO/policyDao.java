package com.cognizant.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.policy;

/*Empid:901096 Name:Amit Gawande*/
@Repository
public interface policyDao extends JpaRepository<policy, Long> {

	@Query(value = "SELECT * FROM policy where policyid=? ", nativeQuery = true)
	public policy getpolicydetails(long policyid);
}
