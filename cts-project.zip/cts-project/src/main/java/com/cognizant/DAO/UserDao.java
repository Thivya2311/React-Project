package com.cognizant.DAO;

import java.io.Serializable;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.model.UserDetails;

@Repository
public interface UserDao extends JpaRepository<UserDetails, Serializable> {

	/* Empid:901013 Name:Thivya Bharathy T */

	@Query(value = "select * from user_tbl where email=?", nativeQuery = true)
	UserDetails find(String email);

	/* Empid:901049 Name:Abhishek E */

	@Transactional
	@Modifying
	@Query(value = "update user_tbl set password=? where email=?", nativeQuery = true)
	int setPassword(String password, String email);

}
