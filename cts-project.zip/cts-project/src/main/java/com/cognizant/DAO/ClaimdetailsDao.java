package com.cognizant.DAO;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.model.Claimdetails;

/*Empid:900886 Name:Harika Bonala*/

public interface ClaimdetailsDao extends JpaRepository<Claimdetails, Long> {

	

}
