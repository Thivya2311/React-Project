package com.cts.stationarybill.exception;

public class InvalidCostPerQuantityException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidCostPerQuantityException(String message) {
		//code here..
	}
}
