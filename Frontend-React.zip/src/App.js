
import './App.css';
import MenuComponent from './Components/MenuComponent';
import {HomeComponent} from './Components/HomeComponent';
import React from 'react'
import {ClaimpolicyComponent} from './Components/ClaimpolicyComponent';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
import { contactcomponent } from './Components/contactcomponent';
import UserForm from './Components/Userform';
import { Policywithsearch } from './Components/policywithsearch';
import { Claimreport } from './Components/Claimreport';
import { AdminHome } from './Components/AdminHome';
import ClaimList from './Components/AdminViewClaim';
import LoginComponent from './Components/LoginComponent';
import AddPolicy from './Components/AddPolicy';
import PolicyList from './Components/PolicyList';
import EditPolicy from './Components/EditPolicy';
import Policy from './Components/Policy';
import AdminClaimReport from './Components/AdminClaimReport';


export const AuthContext =React.createContext();

const initialState = {
  isAuthenticated: false,
  user: null,
  token: null,
};

const reducer = (state, action) => {
  switch (action.type) {
    case "LOGIN":
      localStorage.setItem("user", JSON.stringify(action.payload.user));
      localStorage.setItem("token", JSON.stringify(action.payload.token));
      return {
        ...state,
        isAuthenticated: true,
        user: action.payload.user,
        token: action.payload.token,
      };
    case "LOGOUT":
      localStorage.clear();
      return {
        ...state,
        isAuthenticated: false,
        user: null,
      };
    default:
      return state;
    }
  
};

const ProtectedRoute = ({
  component: Component,
  authstate: state,
  ...rest
}) => {
  return (
    <Route
      {...rest}
      render={() => {
        console.log(localStorage.getItem("user"));
        if (!localStorage.getItem("user"))  return <Redirect to="/" />;
        else return  <Component/>;
      }}
    />
  );
};
function App() {
  const [state, dispatch] = React.useReducer(reducer, initialState);

  React.useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user") || null);
    const token = JSON.parse(localStorage.getItem("token") || null);

    if (user && token) {
      dispatch({
        type: "LOGIN",
        payload: {
          user,
          token,
        },
      });
    }
  }, []);

  return (
    <Router>
      <AuthContext.Provider
        value={{
          state,
          dispatch,
        }}
        
      >
        <MenuComponent />
        {/* <MenuComponentDup/> */}
        <Switch>
          <Route path="/login" exact component={LoginComponent} />
          <Route
            path="/home"
            component={AdminHome}
          />
          <Route path="/" exact component={HomeComponent} />
          <Route path="/claimpolicy" component={ClaimpolicyComponent}/>
          <Route path="/contact" component={contactcomponent}/>
          <Route path="/userform" component={UserForm}/>
          <Route path="/viewpolicies" component={Policywithsearch}/>
          <Route path="/viewreport" component={Claimreport}/>
         <ProtectedRoute
            path="/policy"
            authstate={state}
            component={AddPolicy}
          />
          <ProtectedRoute
            path="/claims"
            authstate={state}
            component={ClaimList}
          />
           
            <ProtectedRoute
            path="/list"
            authstate={state}
            component={PolicyList}
          />
           <ProtectedRoute
            path="/policies/:id" 
            authstate={state}
            component={Policy}
          />
          <ProtectedRoute
            path="/report/:id" 
            authstate={state}
            component={AdminClaimReport}
          />
           
           
          <ProtectedRoute
            path="/updatePolicy/:id" 
            authstate={state}
            component={EditPolicy}
          />
          
          
        
        </Switch>

      </AuthContext.Provider>
    </Router>
  );
}



// function App() {
  
//   return (
//     <div className="App">
//       <Router>
//   <MenuComponent/>
//   <Switch>
//           <Route path="/" exact component={HomeComponent} />
//           <Route path="/claimpolicy" component={ClaimpolicyComponent}/>
//           <Route path="/contact" component={contactcomponent}/>
//           <Route path="/userform" component={UserForm}/>
//           <Route path="/policies" component={Policywithsearch}/>
//           <Route path="/viewreport" component={Claimreport}/>
//           </Switch>
//           </Router>
//     </div>
    
//   );
// }

export default App;
