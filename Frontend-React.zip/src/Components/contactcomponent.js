import React from "react";
import contact from '../contact.JPG';
export class contactcomponent extends React.Component{
    render(){
        return(
            <center> <div>
                <h3>Contact us</h3>
                <br/><br/>
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4">
                    <img src={contact} height="300px" width="400px"/>
                    </div>
                    <div class="col-md-4"></div>
                </div>
                
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4">
                        <a href="mailto:abc@gamil.com">abc@gmail.com</a><br/>
                        +123456789<br/>
                        Cognizant Technology, Chennai-123456
                    </div>
                    <div class="col-md-4"></div>
                </div>
            </div></center>
        );
    }
}