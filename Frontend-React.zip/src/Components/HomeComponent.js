
import React from "react";

import bank from './Images/bank.png';
/*
Empid:900886 
Name:Harika Bonala
*/
export class HomeComponent extends React.Component
{
    render(){
        return(
            <div className="container"><br/><br/>
                <div className="row">
                    <div className="col-md-6">
                        <img src={bank} height="400px;" width="500px;" alt="claim"/>
                    </div>
                    <div className="col-md-6">
                        <h1 className="design-4 ">Welcome To Insurance Claim Management System</h1>
                   <p > Accidents and disasters can and do happen, and if you aren’t adequately insured, it could leave you in financial ruin.
                     You need insurance to protect your life, your ability to earn income, and to keep a roof over your head. As you evaluate 
                    the potential gaps in your insurance coverage, consider which policies you may want to include your short- and long-term financial plan. 
                    </p>
                    <a href="/viewpolicies"><button class="btn btn-dark">Check our policies</button></a>
                    </div>                    
                </div>
                <br/><br/>
            </div>
        );
    }
}