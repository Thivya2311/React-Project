import React, { Component } from 'react'
import { withRouter } from "react-router";
import axios from 'axios'
import {Link} from 'react-router-dom';
import { Table} from 'react-bootstrap';


class Policy extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             policy:{}
        }
    }

    componentDidMount() {
        console.log({props:this.props})
        const id = this.props.match.params.id
        axios.get(`http://localhost:8080/policies/${id}`)
         .then(response => {
             console.log(response.data)
             this.setState({policy: response.data})
         })
    }
    
    render() {
        const policy = this.state.policy
        return (
            <div className="container  mt-5 mb-3">
                    <div>
                        <form>
                            <h1>Policy Report - {policy.name}</h1>
                    <Table bordered hover size="sm">
                    <thead>
                        
                        
                    </thead>
                        <tbody>
                     <tr>
                     <td>Insured Name</td>
                        <td>{policy.name} <br/></td></tr>
                      <tr> 
                      <td>Email</td>
                      <td>  {policy.email} <br/></td>
                      </tr>
                          <tr>

                          <td>Policy Name</td>
                       
                       <td>    {policy.policyName}</td>
                       </tr>
                       <tr>
                        <td>Policy Number</td>

                       <td>   {policy.policyid}</td>
                       </tr>
                        </tbody>
                        </Table>
                        </form>
                        <Link to="/list" className="btn">Back</Link>
                    </div>
            </div>
        )
    }
}

export default withRouter(Policy);