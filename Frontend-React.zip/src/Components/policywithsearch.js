/*Empid:901096
Name:Amit Gawande
*/
import React, { Component } from "react";
import '../Stylesheets/styles.css'
import vehicle_insurance from '../vehicle_insurance.jpg';
import property_insurance1 from '../property_insurance1.jpg';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import lifeinsurance from '../life.jfif';
import {
    Input,
  } from "mdbreact";
import policyList from './policies.json';
import { faSearch } from "@fortawesome/free-solid-svg-icons";
export class Policywithsearch extends Component {
  state = {
    search: ""
  };

  renderpolicy = policy => {
    const { search } = this.state;
    var code = policy.code.toLowerCase();

    return (
      <div className="col-md-4" style={{ marginTop: "20px" }}>
       {/* <h3>{policy.name}</h3>
       {policy.name==='Vehicle'? <img src={vehicle_insurance} />:''}
       <p>{policy.code}</p> */}
       <div className="card ">
        <div className="card-header" style={{fontWeight:"bold",backgroundColor:"black",color:" #76dfd6;"}}>{policy.name}</div>
        <div className="card-body">
        {policy.name==='Vehicle'? <img src={vehicle_insurance} />:''}
        {policy.name==='Property'?<img src={property_insurance1}/>:''}
        {policy.name==='Life'?<img src={lifeinsurance} />:''}
          <p className="card-text">{policy.code}</p>
          </div>
          </div>
      <br/>
       <center><a href="/claimpolicy"><button class="btn btn-dark">Claim now</button></a></center>
      </div>

    );
  };

  onchange = e => {
    this.setState({ search: e.target.value });
  };

  render() {
    const { search } = this.state;
    const filteredpolicy = policyList.filter(policy => {
      return policy.name.toLowerCase().indexOf(search.toLowerCase()) !== -1;
    });

    return (
      <div className="flyout">
        <main style={{ marginTop: "4rem" }}>
          <div className="container">
            <div className="row">
              <div className="col-12">
             
                <center> 
                </center>
              </div>
              <div className="col-4"></div>
              <div className="col-4" >
                <center>
                 
                <Input
                  label="Search Policy"
                  icon="faSearch"
                  
                  onChange={this.onchange}
                />
                </center>
              </div>
              <div className="col" />
            </div>
            <div className="row">
              {filteredpolicy.map(policy => {
                return this.renderpolicy(policy);
              })}
            </div>
          </div>
        </main>
      
      </div>
    );
  }
}


