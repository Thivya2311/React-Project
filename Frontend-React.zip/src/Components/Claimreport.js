import React from "react";
import {Table} from 'react-bootstrap'
import axios from 'axios'
import bank from './Images/bank.png';
var dateFormat=require("dateformat");
/*Empid:900843
Name:Uppuluri Venkata Dharma
*/


export class Claimreport extends React.Component{
    constructor(){
        super();
        this.state={
            policyid:'',
            claimid:'',
            flag:false,
            data:[],
            dateOfLoss:''
        }
    }
    policyHandler=(event)=>{
        this.setState({
            policyid:event.target.value
        })
    }
    claimHandler=(event)=>{
        this.setState({
            claimid:event.target.value
        })
    }
    async fetchData(){
      
        var pid=this.state.policyid;
        var cid=this.state.claimid;
       
        const response=await axios.get(`http://localhost:8080/viewreport/${pid}/${cid}`)
        if(response.data==='')
        {
            alert("please enter valid policy and claim id");
        }
        else { 
        this.setState({
            data:response.data,
            flag:true,
            dateOfLoss:dateFormat(response.data.dateOfLoss,"dd/mm/yyyy")
        })
    }
    }
    
    render(){
        return(
            <div className="container  mt-5 mb-3">
              {this.state.flag?'':
            <div className="row ">
               <div className="col-md-6"><img src={bank} height="400px;" width="500px;" alt="claim"/></div>
                <div className="col-md-6">
              <center><h3>View claim report</h3></center>
              <br/><br/>
              <center><label>Policy id</label></center>
              <input type="text" onChange={this.policyHandler}/>
              <br/><br/>
              <center><label>Claim id</label></center>
              <input type="text" onChange={this.claimHandler}/>
              <center><button class="btn btn-dark"  onClick={this.fetchData.bind(this)}>Verify</button></center>
              </div>
              <div className="col-md-4"></div>
              
            </div>
            }
          {this.state.flag?
          <div><center><h3>Claim report</h3></center><br/>
    <Table striped bordered hover>
      
  <thead>
    <tr>
      <th>policyid</th>
      <th>policyname</th>
      <th>claimid</th>
      <th>Name</th>
      <th>Email</th>
      <th>Location of loss</th>
      <th>Description of loss</th>
      <th>Estimated amount of loss</th>
      <th>Phone number</th>
      <th>Gender</th>
      <th>Date of loss</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>{this.state.data.policyid}</td>
      <td>{this.state.data.policyName}</td>
      <td>{this.state.data.claimid}</td>
      <td>{this.state.data.name}</td>
      <td>{this.state.data.email}</td>
      <td>{this.state.data.locOfLoss}</td>
      <td>{this.state.data.desOfLoss}</td>
      <td>{this.state.data.estLoss}</td>
      <td>{this.state.data.phoneNumber}</td>
      <td>{this.state.data.gender}</td>
      <td>{this.state.dateOfLoss}</td>
    </tr>
  </tbody>
</Table></div>:''}

</div>
        );
    }
}