import React, { Component } from "react";    
import { Form ,Button} from "react-bootstrap";
import '../Stylesheets/styles.css'   
  import axios from'axios';
import { Claimstatus } from "./claimstatus";
/*
Empid:900886 
Name:Harika Bonala
*/

class UserForm extends Component {    
    constructor(){
        super();
        this.state={
          policyid:'',
            name:'',
            email:'',
            estLoss:'',
            phoneNumber:'',
            locOfLoss:'',
            gender:'',
            desOfLoss:'',
            dateOfLoss:'',
            claimstatus:false,
            errors:{
              locError:'',
              phoneError:'',
              genderError:'',
              estError:'',
              desError:'',
              dateError:''
            }
        }
        this.changeLocationOfLossHandler = this.changeLocationOfLossHandler.bind(this);
        this.changeDescriptionOfLossHandler = this.changeDescriptionOfLossHandler.bind(this);
        this.changeEstimatedAmountOfLossHandler = this.changeEstimatedAmountOfLossHandler.bind(this);
        this.changePhoneNumberHandler = this.changePhoneNumberHandler.bind(this);
        this.changeGenderHandler = this.changeGenderHandler.bind(this);
        this.changeDateOfLossHandler = this.changeDateOfLossHandler.bind(this);
        this.changeName = this.changeName.bind(this);
        this.changeEmail = this.changeEmail.bind(this);        
    }
    changeName=(event)=>{
      this.setState({name: event.target.value});
    }
    changeEmail= (event) => {
      this.setState({email: event.target.value});
  }
    changeLocationOfLossHandler= (event) => {
      this.state.errors.locError=(event.target.value === "" ? "Location of loss is required" : "");
      this.setState({locOfLoss: event.target.value});
  }
  changeDescriptionOfLossHandler= (event) => {
    this.state.errors.desError =(event.target.value === "" ? "Destination of loss is required" : "");
    this.setState({desOfLoss: event.target.value});
}
changeEstimatedAmountOfLossHandler= (event) => {
  this.state.errors.estError=(event.target.value === "" ? "Estimation of loss is required" : "");
  this.state.errors.estError=(isNaN(event.target.value)?"Please enter valid amount":"");
  this.setState({estLoss: event.target.value});
}
changePhoneNumberHandler= (event) => {
  var validphoneexp= new RegExp(/^[0-9]{10}$/);
   this.state.errors.phoneError = (validphoneexp.test(event.target.value))? '':"Phone number must be 10 digits"; 
  this.setState({phoneNumber: event.target.value});
}
changeGenderHandler= (event) => {
  this.state.errors.genderError=(event.target.value === "" ? "Gender is required" : "");
  this.setState({gender: event.target.value});
}
changeDateOfLossHandler= (event) => {
  this.state.errors.dateError=(event.target.value === "" ? "Date of loss is required" : "");
  this.setState({dateOfLoss: event.target.value});
}
validateForm = () => {
  let locError = "";  let phoneError = "";  let genderError="";  let estError="";  let desError="";  let dateError="";
  if (this.state.locOfLoss === "") locError = "location of loss is Required";
  var validphoneexp= new RegExp(/^[0-9]{10}$/);
   phoneError = (validphoneexp.test(this.state.phoneNumber))? '':"Phone number must be 10 digits"; 
  if (this.state.phoneNumber === "") phoneError = "Phonenumber Is Required";
  if(this.state.gender=== "") genderError="Gender is required";
  if(this.state.estLoss=== "") estError=" Estimation amount of loss is required";
  if(this.state.desOfLoss==="") desError="Destination of loss is required";
  if(this.state.dateOfLoss==="") dateError="Date of loss is required";
  if (locError === "" && genderError === "" && phoneError===""&& estError==="" && desError==="" && dateError==="") {
    return true;
  } else {
    let err = {
      genderError:genderError,
      locError: locError,
      phoneError: phoneError,
      estError:estError,
      desError:desError,
      dateError:dateError
    };

    this.setState({      
      errors: err,
    });
  }
};
saveUser = (u) => {
  let val=this.validateForm();
  if(val){ 
  this.setState({
    claimstatus:true
  })
  u.preventDefault();
  let user = {policyid:this.props.policyid,name:this.props.name,email:this.props.email,locOfLoss: this.state.locOfLoss, desOfLoss: this.state.desOfLoss,
     estLoss: this.state.estLoss,phoneNumber: this.state.phoneNumber,gender: this.state.gender,dateOfLoss: this.state.dateOfLoss,
    claimid:Number(this.props.policyid)+5,policyName:this.props.policyName};
  console.log('User => ' + JSON.stringify(user));

  axios.post('http://localhost:8080/claimpolicy', user)
  .then((res) => {
      console.log(res.data)
  }).catch((error) => {
      console.log(error)
  });
}
}

    render() {       
        return ( 
            <div class="row">              
                 <div class="col-md-2"></div> 
                 
                 <div class="col-md-8">
                 {this.state.claimstatus? <Claimstatus claimid={Number(this.props.policyid)+5}/>:
            <Form>
            <div class="row">
              <div class="col-md-6">
                <Form.Group>
                  <Form.Label>Policy id</Form.Label>
      <Form.Control type="text" value={this.props.policyid}></Form.Control>
                </Form.Group>
                <Form.Group>
                  <Form.Label>Policy name</Form.Label>
                  <Form.Control type="text" value={this.props.policyName}></Form.Control>
                </Form.Group>
  <Form.Group >
          <Form.Label>Name</Form.Label>
          <Form.Control type="text" required="required" value={this.props.name} onChange={this.changeName}></Form.Control>
      </Form.Group>
      <Form.Group>
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" value={this.props.email} required placeholder="name@example.com" onChange={this.changeEmail}/>
  </Form.Group>
  
  <Form.Group>    
    <Form.Label>Location of loss</Form.Label>
    <Form.Control type="text" required="required"  value={this.state.locOfLoss} onChange={this.changeLocationOfLossHandler} />
    {this.state.errors.locError !== "" ? <p style={{color:"red"}} >{this.state.errors.locError}</p> : ""}
  </Form.Group>
  </div>  
  <div class="col-md-6">
  <Form.Group>
    <Form.Label>Description of Loss</Form.Label>
    <Form.Control as="textarea"required rows={1}   value={this.state.desOfLoss} onChange={this.changeDescriptionOfLossHandler} />
    {this.state.errors.desError !== "" ? <p style={{color:"red"}}>{this.state.errors.desError}</p> : ""}
  </Form.Group>
  <Form.Group>
    <Form.Label>Estimated amount of Loss</Form.Label>
    <Form.Control type="text" required  value={this.state.estLoss} onChange={this.changeEstimatedAmountOfLossHandler} />
    {this.state.errors.estError !== "" ? <p style={{color:"red"}}>{this.state.errors.estError}</p> : ""}
  </Form.Group>
  <Form.Group>
      <Form.Label>Phone number</Form.Label>
      <Form.Control required type="text"  value={this.state.phoneNumber} onChange={this.changePhoneNumberHandler} />
      {this.state.errors.phoneError !== "" ? <p style={{color:"red"}}>{this.state.errors.phoneError}</p> : ""}
  </Form.Group>
  <Form.Group controlId="exampleForm.ControlSelect1">
    <Form.Label>Gender</Form.Label>
    <Form.Control as="select"  value={this.state.gender} onChange={this.changeGenderHandler} >
    <option value="">Select</option>
      <option value="F">F</option>
      <option value="M">M</option>      
    </Form.Control>
    {this.state.errors.genderError !== "" ? <p style={{color:"red"}} >{this.state.errors.genderError}</p> : ""}
  </Form.Group>
  <Form.Group>
      <Form.Label>Date of Loss</Form.Label>
      <Form.Control type="date" required   value={this.state.dateOfLoss} onChange={this.changeDateOfLossHandler}></Form.Control>
      {this.state.errors.dateError !== "" ? <p style={{color:"red"}}>{this.state.errors.dateError}</p> : ""}
  </Form.Group><br/>
  <button className="btn btn-success" size="sm" onClick={this.saveUser}>Submit</button>
  </div>  
</div>
</Form> }
</div>
<div class="col-md-2"></div> 
</div>
        )    
    }    
}    
    
export default UserForm;