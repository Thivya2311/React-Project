import React from "react";
import { Form } from "react-bootstrap";
import axios from 'axios';
import UserForm from "./Userform";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faLongArrowAltLeft } from '@fortawesome/free-solid-svg-icons'
import bank from './Images/bank.png';
/*Empid:901096
Name:Amit Gawande
*/
export class ClaimpolicyComponent extends React.Component{

    constructor(){
        super();
        this.state={
            policyid:'',
            data:[],
            flag:false,
            status:false
        }
    }
    onchange=(event)=>{
        this.setState({
            policyid:event.target.value
        })
    }
    async fetchData(){
        var id=Number(this.state.policyid);
        try{ 
        const response=await axios.get(`http://localhost:8080/claimpolicy/${id}`)
        if(response.data==='')
        {
            alert("please enter valid policy id");
        }
        else {
        this.setState({
            data:response.data,
            status:true,
            flag:true
        })
    }
}
        catch(err){
            console.log(err)
          }
        }
    render(){
        return(
           <div className="container  mt-5 mb-3 ">
            {this.state.status?'':<div className="row"><br/>
           
            <div className="col-md-6"><img src={bank} height="400px;" width="500px;" alt="claim"/></div>
            <div className="col-md-6">   
             <center> <h3> Claim for policy</h3> </center>
            <br/><br/>                
            <center><label>Policy id</label><br/></center>
        <input type="text" name="" onChange={this.onchange}></input><br/><br/>
            <center><button class="btn btn-dark"  onClick={this.fetchData.bind(this)}>Verify</button></center>
        </div>
        <div className="col-md-4"></div>

        </div>}
        {this.state.flag?<div className="row">
            <h1 style={{textAlign:"left",marginLeft:"20px"}}> <a href="/viewpolicies" style={{color:"black"}}><FontAwesomeIcon icon={faLongArrowAltLeft} /></a></h1><br/>
        <div className="col-md-2"></div>
        <div className="col-md-8">
            
            <center><h3>Claim form</h3></center>
            <br/><br/>
        <UserForm name={this.state.data.name} email={this.state.data.email} policyid={this.state.policyid} policyName={this.state.data.policyName}/>
        </div>
        <div className="col-md-2"></div> 
        </div>:''}
        </div>

        );
    }
}