import "bootstrap/dist/css/bootstrap.min.css";
import $ from "jquery";
import Popper from "popper.js";
import "bootstrap/dist/js/bootstrap.bundle.min";
import { Navbar, Nav, Container } from 'react-bootstrap';
import "../Stylesheets/mystyle.css";
import { Link, NavLink } from "react-router-dom";
import {NavDropdown} from 'react-bootstrap';

import React, { useState } from "react";
import { AuthContext } from "../App";

function MenuComponentDup() {
  const { state, dispatch } = React.useContext(AuthContext);
  let menulist;
  if (!state.isAuthenticated)
    menulist = (
      <>
        <li className="nav-item ">
          <NavLink className="nav-link " exact to="/login">
            Login
          </NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link" to="/">Home</NavLink>
        </li>
        <li className="nav-item">          
        <NavLink className="nav-link " to="/viewpolicies">
            Policies          
            </NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link" to="/viewreport">
            Claim Report
          </NavLink>
        </li>
        <li className="nav-item">          
        <NavLink className="nav-link" to="/contact">
           Contact
           </NavLink>
        </li>       
  
      </>
    );
  else
    menulist = (
      <>
        <li className="nav-item ">
          <NavLink className="nav-link " to="/home">
            Home
          </NavLink>
        </li>
        <li>
        <NavDropdown title="Policy" id="basic-nav-dropdown">
        <NavDropdown.Item><Link to="/policies">Policy Details</Link></NavDropdown.Item>
        <NavDropdown.Item><Link to="/policy">Add User Policy</Link></NavDropdown.Item>
        <NavDropdown.Item><Link to="/list">View Policy</Link></NavDropdown.Item>
        
       
      </NavDropdown>
        </li>
        
        <li>
        <NavDropdown title="Claim" id="basic-nav-dropdown">
        <NavDropdown.Item ><Link to="/claims">Claim Details</Link></NavDropdown.Item>
        {/* <NavDropdown.Item href="/policy">Edit Claim Details</NavDropdown.Item> */}
       
       
      </NavDropdown>
        </li>
      
        <li className="nav-item">
          <NavLink
            className="nav-link"
             exact
            to="/"
            onClick={() => {
              dispatch({
                type: "LOGOUT",
              });
            }}
          >
            Logout
          </NavLink>
        </li>
      </>
    );
  return (
    <>
    <Navbar style={{backgroundColor:"black"}} variant="dark" expand="lg">
  <Navbar.Brand href=""><h3 className="design-6" style={{color: "#76dfd6"}}>Insurance Claim Management</h3></Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="ml-auto">
      <ul className="navbar-nav mr-auto">
          {menulist}</ul> 
          </Nav>
  </Navbar.Collapse>
</Navbar>
    </>
  );
}

export default MenuComponentDup;
