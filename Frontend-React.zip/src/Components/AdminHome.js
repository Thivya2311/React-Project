import React from "react";
import {Col, Row,Card} from 'react-bootstrap';
import Policy from './Images/Policy.png';
import {Link} from 'react-router-dom';
import bank from './Images/bank.png';
export class AdminHome extends React.Component{
    render(){
        return(
            <div className="container  mt-5 mb-3">
                <Row>
                    <Col>
                    <img src={bank} height="400px;" width="500px;" alt="claim"/>
                    </Col>
                    <Col>
                    
                    <h1 style={{color:"black"}}>WELCOME TO INSURANCE CLAIM MANAGEMENT SYSTEM, ADMIN</h1>
                    <p>You have your access to view,edit Policy Details as well as Claim Details.
                    As a Admin,You must be responsible in maintaing the data for our organization.</p>
                   
                   
                    <Row>
                        <Col>
                    <Link to="/list"><button className="btn btn-primary">Visit Policy Details</button></Link></Col>
                    <Col><Link to="/claims"><button className="btn btn-primary">Visit Claim Details</button></Link>
                    </Col>
                    </Row>
                    </Col>
                </Row>
                <hr/>
                
                
            </div>
        )
    }
}