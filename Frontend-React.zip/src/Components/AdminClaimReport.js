import React, { Component } from 'react'
import { withRouter } from "react-router";
import axios from 'axios'
import {Link} from 'react-router-dom';
import { Table} from 'react-bootstrap';
var dateFormat=require("dateformat");
/*Empid:900843
Name:Uppuluri Venkata Dharma Teja
*/

class AdminClaimReport extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             claim:{}
        }
    }

    componentDidMount() {
        console.log({props:this.props})
        const id = this.props.match.params.id
        axios.get(`http://localhost:8080/claims/${id}`)
         .then(response => {
             console.log(response.data)
             this.setState({claim: response.data})
         })
    }
    
    render() {
        const claim = this.state.claim
        return (
            <div className="container  mt-5 mb-3">
                    <div>
                        <form>
                            <h1>Claim Report - {claim.name}</h1>
                    <Table bordered hover size="sm">
                    <thead>
                        
                        
                    </thead>
                        <tbody>
                     <tr>
                     <td>Insured Name:</td>
                        <td>{claim.name} <br/></td></tr>
                        <tr>
                          <td>Gender:</td>
                          <td>  {claim.gender} <br/></td>
                          </tr>
                      <tr> 
                      <td>Email</td>
                      <td>  {claim.email} <br/></td>
                      </tr>
                      <tr> 
                          <td>Phone Number:</td>
                          <td>  {claim.phoneNumber} <br/></td>
                          </tr>
                          <tr>

                          <td>Policy Name</td>
                       
                       <td>    {claim.policyName}</td>
                       </tr>
                       <tr>
                        <td>Policy Number</td>

                       <td>   {claim.policyid}</td>
                       </tr>
                       <tr> 
                          
                          <td>Claim Number:</td>
                          <td>  {claim.claimid} <br/></td>
                          </tr>
                          <tr> 
                          
                          <td>Location Of Loss:</td>
                          <td>  {claim.locOfLoss} <br/></td>
                          </tr>
                          <tr> 
                          
                          <td>Description of Loss:</td>
                          <td>  {claim.desOfLoss} <br/></td>
                          </tr>
                          <tr> 
                          
                          <td>Estimated Amount of Loss:</td>
                          <td>  {claim.estLoss} <br/></td>
                          </tr>
                          <tr> 
                          
                          <td>Date Of Loss</td>
                          <td> {dateFormat(claim.dateOfLoss,"dd/mm/yyyy")} <br/></td>
                          </tr>
                        </tbody>
                        </Table>
                        </form>
                        <Link to="/claims" className="btn">Back</Link>
                    </div>
            </div>
        )
    }
}

export default withRouter(AdminClaimReport);