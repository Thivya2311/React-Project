import React,{useState, useEffect} from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'
import {Table} from 'react-bootstrap';

export default function PolicyList(props) {
    const [policyList, setPolicyList] = useState([])

    useEffect(() => {
        axios.get('http://localhost:8080/policies')
         .then(response => {
             setPolicyList(response.data)
             
         })
    },[])

    const deletePolicy = (id) => {
        axios.delete(`http://localhost:8080/policies/${id}`)
        .then(res => {
            console.log("Data Deleted")
            
            alert("Deleted")
            window.location.href="http://localhost:3000/list"
            props.history.push('/list')
        })
        .catch(err => console.log(err))
    }


    return (
        <div className="container  mt-5 mb-3 ">
            <Table striped bordered hover size="sm">
             
                <thead>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Policy Name</th>
                    <th>Policy Number</th>
                    <th></th>
                    <th></th>
                   
                </thead>
                <tbody>
                    {policyList.map(policy => (
                        <tr key={policy.policyid}>
                            <td>{policy.name}</td>
                            <td>{policy.email}</td>
                            <td>{policy.policyName}</td>
                            <td>{policy.policyid}</td>
                            {/* <td>{policy.policyNo}</td> */}
                            <td>
                                <Link to={"/policies/"+policy.policyid}>
                                    <button className="btn-primary">Report</button>
                                </Link>
                            </td>
                            <td>
                              <button  className="btn-primary" onClick={() => deletePolicy(policy.policyid)}>Delete</button> 
                            </td>
                            <td>
                                <Link to={"/updatePolicy/"+policy.policyid}>
                                    <button  className="btn-primary">Edit</button>
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
           </Table>
            <br/>
            <Link to="policy">
                <button  className="btn-primary">Add New Person</button>
            </Link>
        </div>
    )
}
