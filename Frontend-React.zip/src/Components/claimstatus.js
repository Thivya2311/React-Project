import React from "react";
/*
Empid:900886 
Name:Harika Bonala
*/
export class Claimstatus extends React.Component{
    render(){
        return(
            <div>
            <h4 style={{color:"green"}}>Your claim was submitted successfully and your claim id is <u> {this.props.claimid}</u> </h4>
            <br/><br/>
            <center><a href="/viewreport"><button className="btn btn-dark">View Report</button></a></center>
            </div>
        );
    }
}