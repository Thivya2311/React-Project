import React,{useState, useEffect} from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'
import {Table} from 'react-bootstrap';
var dateFormat=require("dateformat");
export default function ClaimList(props) {
    const [claimList, setClaimList] = useState([])

    useEffect(() => {
        axios.get('http://localhost:8080/claims')
         .then(response => {
             setClaimList(response.data)
             
         })
    },[])

    const deleteClaim = (id) => {
        axios.delete(`http://localhost:8080/claims/${id}`)
        .then(res => {
            console.log("Data Deleted")
            
            alert("Deleted")
            window.location.href="http://localhost:3000/claims"
            props.history.push('/claim')
        })
        .catch(err => console.log(err))
    }


    return (
        <div className="container  mt-5 mb-3 ">
            <Table striped bordered hover size="sm">
             
                <thead>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Policy Name</th>
                    <th>Policy Number</th>
                    <th>Claim Number</th>
                    <th>Location of Loss</th>
                    <th>Decription of Loss</th>
                    <th>Estimated Amount Of Loss</th>
                    <th>Date of Loss</th>
                    <th></th>
                    <th></th>
                   
                </thead>
                <tbody>
                    {claimList.map(claim => (
                        <tr key={claim.policyid}>
                            <td>{claim.name}</td>
                            <td>{claim. gender} </td>
                            <td>{claim.email}</td>
                            <td>{claim.phoneNumber} </td>
                            <td>{claim.policyName}</td>
                            <td>{claim.policyid}</td>
                            <td>{claim.claimid} </td>
                            <td>{claim.locOfLoss} </td>
                            <td>{claim.desOfLoss} </td> 
                            <td>{claim.estLoss} </td>
                            <td>{dateFormat(claim.dateOfLoss,"dd/mm/yyyy")} </td>
                            
                            
                            <td>
                                <Link to={"/report/"+claim.policyid}>
                                    <button className="btn-primary">Report</button>
                                </Link>
                            </td>
                            <td>
                              <button  className="btn-primary" onClick={() => deleteClaim(claim.policyid)}>Delete</button> 
                            </td>
                            
                        </tr>
                    ))}
                </tbody>
           </Table>
            <br/>
            <Link to="/home" className="btn">Back</Link>
        </div>
    )
}
