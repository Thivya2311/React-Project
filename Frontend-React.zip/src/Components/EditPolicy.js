import React,{useState, useEffect} from 'react'
import { useParams,Link } from 'react-router-dom'

import axios from 'axios'

export default function AddPolicy(props) {
    const[policyid,setPolicyId]=useState('')
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const[policyName, setPolicyName] = useState('')
    //const[policyNo,setPolicyNo]=useState('')
    const { id } = useParams();

    useEffect(() => {
        axios.get(`http://localhost:8080/policies/${id}`)
         .then(response => {
             
             setPolicyId(response.data.policyid)
             setName(response.data.name)
             setEmail(response.data.email)
             setPolicyName(response.data.policyName)
           //  setPolicyNo(response.data.policyNo)
         })
    },[])

    const handleSubmit = e => {
        e.preventDefault()
        axios.put(`http://localhost:8080/policies/${id}`,{
            name: name,
            email:email,
            policyName:policyName,
            policyid:policyid
        })
        .then(res => {
            console.log("Data updated")
            alert("Data Updated")
             props.history.push('/list')
             
        })
        .catch(err => console.log(err))
    }


    return (
        <div>
            <form>
                <div>
                    <label>Name: </label>
                    <input type="text" name="name" value={name} onChange={e => setName(e.target.value)}/>
                </div>
                <div>
                    <label>Email:</label>
                    <input type="text" name="email" value={email} onChange={e => setEmail(e.target.value)}/>
                </div>
                <div>
                    <label>Policy Name:</label>
                    <input type="text" name="policyName" value={policyName} onChange={e => setPolicyName(e.target.value)}/>
                </div>
                <div>
                    <label>Policy Number:</label>
                    <input type="text" name="policyid" value={policyid} onChange={e => setPolicyId(e.target.value)}/>
                </div>
                <Link to="/home"><button onClick={handleSubmit}>Update Policy</button></Link>
            </form>
        </div>
    )
}
