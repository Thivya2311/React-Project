import React,{useState} from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'
import {Col, Row, Table} from 'react-bootstrap';
import Policy from './Images/Policy.png';
import bank from './Images/bank.png';

export default function AddPolicy(props) {
    
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const[policyName, setPolicyName] = useState('')
    const[policyNo,setPolicyNo]=useState('')


    const handleSubmit = e => {
        e.preventDefault()
        axios.post('http://localhost:8080/policy',{
            name: name,
            email:email,
            policyName:policyName,
            policyid:policyNo
        })
        .then(res => {
            console.log("Data added")
            alert("Added");
            props.history.push("/home")
        })
        .catch(err => console.log(err))
    }


    return (
        <div className="container  mt-5 mb-3 ">
            <Row>
                <Col>
                <img src={bank} height="400px;" width="500px;" alt="claim"/>
                </Col>
                  <Col>
            <form>
                <h1 className="design-5">Enter Policy Details</h1>
            <Table striped bordered hover size="sm" style={{width:"25rem"}} >
             
              <tbody>
                
                <tr>
                    
                   <td> <label>Name: </label></td>
                   <td> <input type="text" name="name" value={name} placeholder="Enter Insured Name"
                    onChange={e => setName(e.target.value)}/></td>
                    </tr>
                    <tr>
                
                    <td><label>Email:</label></td>
                    <td><input type="text" name="email" placeholder="name@example.com" value={email} 
                    onChange={e => setEmail(e.target.value)}
                    
                    /></td>
                    
                    </tr>
                    <tr>
                <td><label>Policy Name:</label></td>
                <td> <input type="text" name="policyname"  placeholder="Enter Policy Name" value={policyName} onChange={e => setPolicyName(e.target.value)}/></td>
                </tr>
                <tr>
                
                <td><label>Policy Number:</label></td>
                <td> <input type="text" name="policyno"  placeholder="Enter Policy Number" value={policyNo} onChange={e => setPolicyNo(e.target.value)}/></td>
                </tr>
        
               
                </tbody>
               </Table>
               <Row>
                   <Col className="sm-6">
                   <button onClick={handleSubmit}>Add Policy</button>
                   </Col>
                   <Col className="sm-6 ml-auto">
                   <Link to="/list" className=" btn">View Policy</Link>
                   </Col>
                
               </Row>
               
            </form>
            <br/>
            </Col>
            </Row>
            
        </div>
    )
}
