import React, { Component, useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import $ from "jquery";
import Popper from "popper.js";
import "bootstrap/dist/js/bootstrap.bundle.min";
import bank from './Images/bank.png';
import "../Stylesheets/mystyle.css";
import MenuComponent from "./MenuComponent";
import { Redirect } from "react-router-dom";
import { AuthContext } from "../App";
import axios from "axios";
import {Row,Col} from 'react-bootstrap';
//import { ResetPassword } from "./ResetPassword";
import { useHistory } from "react-router-dom";

export const LoginComponent = (props) => {
  const { dispatch } = React.useContext(AuthContext);

  const initialState = {
    email: "",
    password: "",
    confirmPassword: "",
    errors: {
      email: "",
      pass: "",
    },
    invalidLogin: "",
    isLoggingIn: true
  };

  const [state, setState] = useState(initialState);

  let passError, emailError;
  const validateForm = () => {
    let emailError = "";
    let passwordError = "";
    let passwordMatchError = "";
    console.log(state.email, state.password, state.confirmPassword)

    if (state.email === "") emailError = "Email Is Required";
    if (state.password === "") passwordError = "Password Is Required";
    if (!state.isLoggingIn) {
      if (state.password !== state.confirmPassword) {
        passwordMatchError = "Password missmatch"
      }
    }
    if (emailError === "" && passwordError === "" && passwordMatchError === "") {
      return true;
    } else {
      let err = {
        email: emailError,
        pass: passwordError,
        passMatch: passwordMatchError,
      };

      setState({
        ...state,
        errors: err,
        invalidLogin: "",
      });
    }
  };

  const handleChange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.value,
    });
  };
  const history = useHistory();

  const handleForm = () => {
    setState({
      isLoggingIn: !state.isLoggingIn,
      email: "",
      password: "",
      confirmPassword: "",
    })
  }


  function handleLogin(event) {
    event.preventDefault();
    let val = validateForm();
    console.log(val);
    console.log(state.errors);
    if (val) {
      let user = {
        email: state.email,
        password: state.password,
      };
      axios
        .post("http://localhost:8080/api/user/login", user)
        .then((res) => {
          console.log(res.data);
          dispatch({
            type: "LOGIN",
            payload: {
              user: state.email,
              token: "token",
            },
          });
          props.history.push("/home");
        })
        .catch((err) => {
          setState({
            ...state,
            errors: {
              email: "",
              pass: "",
            },
            invalidLogin: "Invalid Email/Password",
          });
        });
    }
  }

  function handlePasswordChange(event) {
    event.preventDefault();
    let val = validateForm();
    console.log(val);
    console.log(state.errors);
    if (val) {
      let user = {
        email: state.email,
        password: state.password,
      };

      axios
        .post("http://localhost:8080/api/user/changePassword", user)
        .then((res) => {
          console.log(res.data);
          history.go(0)
        })
        .catch((err) => {
          setState({
            ...state,
            errors: {
              email: "",
              pass: "",
            },
            invalidLogin: "Invalid Email/Password",
          });
        });
    }
  }

  return (
    <div>
      <div className="container  mt-5 mb-3">
        <Row>
        <Col>
        <img src={bank} height="400px;" width="500px;" alt="claim"/>
        </Col>
        <div className="card mx-auto h-90 login">
        
          <h2 className="card-header">Admin Login</h2>
          <div className="container">
            <div style={{ color: "#ff0000" }} className="mt-3">
              Fields marked with * are mandatory
              <ul >
                {state.errors && state.errors.email !== "" ? <li>{state.errors.email}</li> : ""}
                {state.errors && state.errors.pass !== "" ? <li>{state.errors.pass}</li> : ""}
                {state.errors && state.errors.passMatch !== "" ? <li>{state.errors.passMatch}</li> : ""}
                {state.invalidLogin !== "" ? <li>{state.invalidLogin}</li> : ""}
              </ul>
            </div>
            {state.isLoggingIn ?
              <form onSubmit={handleLogin}>
                <div className="form-row mb-2 mt-2">
                  <div className="form-group col-12">
                    <label htmlFor="inputEmail Address">
                      Email Address<span style={{ color: "#ff0000" }}>*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      name="email"
                      value={state.email}
                      onChange={handleChange}
                      placeholder="Email Address"
                    />
                  </div>
                </div>
                <div className="form-row mb-2 ">
                  <div className="form-group col-12 ">
                    <label htmlFor="inputPassword">
                      Password<span style={{ color: "#ff0000" }}>*</span>
                    </label>
                    <input
                      type="password"
                      className="form-control"
                      name="password"
                      value={state.password}
                      onChange={handleChange}
                      placeholder="Password"
                    />

                    <div id="id2" className="text-danger"></div>
                  </div>
                </div>

                <div className="d-flex flex-row">
                  <Row>
                    <Col>
                  <button type="submit" className="btn btn-primary mb-4">
                    {" "}
                    Login
                  </button></Col> 
                  <Col>
                  <button className="btn btn-primary mb-4"
                    onClick={handleForm}>
                    ResetPassword
                  </button>
                  </Col>
                  </Row>
                </div>
              </form> :
              <form onSubmit={handlePasswordChange}>
                <div className="form-row mb-2 mt-2">
                  <div className="form-group col-12">
                    <label htmlFor="inputEmail Address">
                      Email Address<span style={{ color: "#ff0000" }}>*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      name="email"
                      value={state.email}
                      onChange={handleChange}
                      placeholder="Email Address"
                    />
                  </div>
                </div>
                <div className="form-row mb-2 ">
                  <div className="form-group col-12 ">
                    <label htmlFor="inputPassword">
                      Password<span style={{ color: "#ff0000" }}>*</span>
                    </label>
                    <input
                      type="password"
                      className="form-control"
                      name="password"
                      value={state.password}
                      onChange={handleChange}
                      placeholder="Password"
                    />
                    <div id="id2" className="text-danger"></div>
                  </div>
                </div>
                <div className="form-row mb-2 ">
                  <div className="form-group col-12 ">
                    <label htmlFor="inputPassword">
                      Confirm Password<span style={{ color: "#ff0000" }}>*</span>
                    </label>
                    <input
                      type="password"
                      className="form-control"
                      name="confirmPassword"
                      value={state.confirmPassword}
                      onChange={handleChange}
                      placeholder="Password"
                    />
                    <div id="id2" className="text-danger"></div>
                  </div>

                </div>
                
                <div className="d-flex flex-row">
                <Row>
                  <Col>
                  <button type="submit" className="btn btn-primary mb-4">
                    {" "}
                    Change Password
                  </button>
                  </Col>
                  <Col>
                  <button className="btn btn-primary mb-4"
                    onClick={handleForm}>
                    Cancel
                  </button>
                  </Col>
                  </Row>
                </div>
              </form>
            }
          </div>
        </div>
        </Row>
      </div>
      <hr/>
     
    </div>
  );
};

export default LoginComponent;